"""
Contains code specific to the legacy TCP API for interacting with the TCL based GUI.
"""
