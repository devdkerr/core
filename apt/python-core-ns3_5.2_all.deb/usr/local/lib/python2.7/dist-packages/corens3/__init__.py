"""
corens3

Python package containing CORE components for use
with the ns-3 simulator.

See http://www.nrl.navy.mil/itd/ncs/products/core and
http://code.google.com/p/coreemu/ for more information on CORE.
"""
