from core.utils import which

COREDPY_VERSION = "5.5.2"
CORE_CONF_DIR = "/etc/core"
CORE_DATA_DIR = "/usr/share/core"
QUAGGA_STATE_DIR = "/var/run/quagga"
FRR_STATE_DIR = "/var/run/frr"

VNODED_BIN = which("vnoded", required=True)
VCMD_BIN = which("vcmd", required=True)
BRCTL_BIN = which("brctl", required=True)
SYSCTL_BIN = which("sysctl", required=True)
IP_BIN = which("ip", required=True)
ETHTOOL_BIN = which("ethtool", required=True)
TC_BIN = which("tc", required=True)
EBTABLES_BIN = which("ebtables", required=True)
MOUNT_BIN = which("mount", required=True)
UMOUNT_BIN = which("umount", required=True)
OVS_BIN = which("ovs-vsctl", required=False)
OVS_FLOW_BIN = which("ovs-ofctl", required=False)
